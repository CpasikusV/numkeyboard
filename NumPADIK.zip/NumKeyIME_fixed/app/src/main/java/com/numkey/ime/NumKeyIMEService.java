package com.numkey.ime;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.inputmethodservice.InputMethodService;
import android.media.AudioAttributes;
import android.media.SoundPool;
import android.os.Build;
import android.os.Handler;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.GridView;
import android.widget.ArrayAdapter;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

public class NumKeyIMEService extends InputMethodService implements View.OnClickListener {

    // ── Prefs ──────────────────────────────────────────────────────────────
    public static final String PREFS_NAME            = "numkey_prefs";
    public static final String KEY_ROW_HEIGHT        = "row_height_dp";
    public static final int    DEFAULT_ROW_HEIGHT     = 64;
    public static final String KEY_ALPHA_ROW_HEIGHT   = "alpha_row_height_dp";
    public static final int    DEFAULT_ALPHA_ROW_HEIGHT = 60;
    public static final String KEY_SOUND_ENABLED     = "sound_enabled";
    private static final String KEY_LAST_MODE        = "last_mode";
    private static final String KEY_PINNED           = "keyboard_pinned";
    private static final String WMS_TEXT             = "10.1.0.145";

    // ── Режими ────────────────────────────────────────────────────────────
    private static final int MODE_NUM   = 0;
    private static final int MODE_ALPHA = 1;
    private static final int MODE_SYM   = 2;
    private static final int MODE_SYM2  = 3;

    private static final int SHIFT_OFF  = 0;
    private static final int SHIFT_ONE  = 1;
    private static final int SHIFT_CAPS = 2;

    private static final int LANG_EN = 0;
    private static final int LANG_UK = 1;

    private int currentMode = MODE_NUM;
    private int shiftState  = SHIFT_OFF;
    private int currentLang = LANG_EN;
    private boolean isPinned = false;

    // ── Розкладки ─────────────────────────────────────────────────────────
    // EN: 26 букв + 5 порожніх (extra slots)
    private static final String[] EN_KEYS = {
        "q","w","e","r","t","y","u","i","o","p",
        "a","s","d","f","g","h","j","k","l",
        "z","x","c","v","b","n","m",
        "","","","","",""
    };
    // UK: й,ц,у,к,е,н,г,ш,щ,з,х,ї (extra)
    //     ф,і,в,а,п,р,о,л,д,ж,є (extra)
    //     я,ч,с,м,и,т,ь,б,ю,ґ (extra)
    private static final String[] UK_KEYS = {
        // ряд1: й ц у к е н г ш щ з
        "\u0439","\u0446","\u0443","\u043a","\u0435","\u043d","\u0433","\u0448","\u0449","\u0437",
        // ряд2: ф і в а п р о л д
        "\u0444","\u0456","\u0432","\u0430","\u043f","\u0440","\u043e","\u043b","\u0434",
        // ряд3: я ч с м и т ь б ю
        "\u044f","\u0447","\u0441","\u043c","\u0438","\u0442","\u044c",
        // extra: х(26) ж(27) є(28) б→не треба ю→не треба ї(31) ґ(32)
        "\u0445","\u0436","\u0454","\u0431","\u044e","\u0457","\u0491"
    };

    private static final String[][] LAYOUTS     = { EN_KEYS, UK_KEYS };
    private static final String[]   LANG_LABELS = {
        "QWERTY",
        "\u0423\u043a\u0440\u0430\u0457\u043d\u0441\u044c\u043a\u0430"
    };

    // ── Спецсимволи під буквами (верхній правий кут KeyButton) ────────────
    // Порядок відповідає LETTER_IDS (26 букв: 0-9 ряд1, 10-18 ряд2, 19-25 ряд3)
    // KEY_SYMBOLS: відповідає Gboard (верхній правий кут кнопки)
    // ряд1: q=% w=\ e=| r== t=[ y=] u=< i=> o={ p=}
    // ряд2: a=@ s=# d=$ f=_ g=& h=- j=+ k=( l=)
    // ряд3: z=* x=" c=' v=: b=; n=! m=?
    private static final String[] KEY_SYMBOLS = {
        "%","\\","|","=","[","]","<",">","{","}",
        "@","#","$","_","&","-","+","(",")",
        "*","\"","'",":",";"  ,"!","?"
    };

    // ── Символи popup для крапки ──────────────────────────────────────────
    private static final String[] DOT_POPUP_SYMBOLS = {
        "&", "%", "+", "\"", "-", ":", "'", "@",
        ";", "/",  "(", ")",  "#", "!", ",", "?"
    };

    // ── Long-press варіанти (буква → альтернатива) ────────────────────────
    // е(idx=4 EN/RU/UK) → ё;  є(idx=28 UK extra) → э;  ь(idx=25) → ъ (RU)
    // Реалізовано в buildAlphaView()

    // ── IDs букв ──────────────────────────────────────────────────────────
    private static final int[] LETTER_IDS = {
        R.id.a_k0,R.id.a_k1,R.id.a_k2,R.id.a_k3,R.id.a_k4,
        R.id.a_k5,R.id.a_k6,R.id.a_k7,R.id.a_k8,R.id.a_k9,
        R.id.a_k10,R.id.a_k11,R.id.a_k12,R.id.a_k13,R.id.a_k14,
        R.id.a_k15,R.id.a_k16,R.id.a_k17,R.id.a_k18,
        R.id.a_k19,R.id.a_k20,R.id.a_k21,R.id.a_k22,
        R.id.a_k23,R.id.a_k24,R.id.a_k25
    };
    private static final int[] EXTRA_IDS = {
        R.id.a_k9b,R.id.a_k9c,R.id.a_k18b,R.id.a_k18c,R.id.a_k25b,R.id.a_k25c,R.id.a_k25d
    };
    private static final int[] EXTRA_LAYOUT_IDX = { 26,31,27,28,29,30,32 };

    private static final int[] ALPHA_NUM_IDS = {
        R.id.a_n1,R.id.a_n2,R.id.a_n3,R.id.a_n4,R.id.a_n5,
        R.id.a_n6,R.id.a_n7,R.id.a_n8,R.id.a_n9,R.id.a_n0
    };
    private static final int[] SYM_NUM_IDS = {
        R.id.s_n1,R.id.s_n2,R.id.s_n3,R.id.s_n4,R.id.s_n5,
        R.id.s_n6,R.id.s_n7,R.id.s_n8,R.id.s_n9,R.id.s_n0
    };
    private static final int[] SYM_IDS = {
        R.id.s_k0,R.id.s_k1,R.id.s_k2,R.id.s_k3,R.id.s_k4,
        R.id.s_k5,R.id.s_k6,R.id.s_k7,R.id.s_k8,R.id.s_k9,
        R.id.s_k10,R.id.s_k11,R.id.s_k12,R.id.s_k13,R.id.s_k14,
        R.id.s_k15,R.id.s_k16
    };
    private static final String[] SYM_VALS = {
        "@","#","$","_","&","-","+","(",")","/",
        "*","\"","'",":",";"  ,"!","?"
    };
    private static final int[] SYM2_IDS = {
        R.id.s2_k0,R.id.s2_k1,R.id.s2_k2,R.id.s2_k3,R.id.s2_k4,
        R.id.s2_k5,R.id.s2_k6,R.id.s2_k7,R.id.s2_k8,R.id.s2_k9,
        R.id.s2_k10,R.id.s2_k11,R.id.s2_k12,R.id.s2_k13,R.id.s2_k14,
        R.id.s2_k15,R.id.s2_k16,R.id.s2_k17,R.id.s2_k18,R.id.s2_k19,
        R.id.s2_k20,R.id.s2_k21,R.id.s2_k22,R.id.s2_k23,R.id.s2_k24,
        R.id.s2_k25,R.id.s2_k26
    };
    private static final String[] SYM2_VALS = {
        "~","`","|","\u2022","\u221a","\u03c0","\u00f7","\u00d7","\u00a7","\u25b3",
        "\u00a3","\u00a2","\u20ac","\u00a5","^","\u00b0","=","{","}","\\",
        "%","\u00a9","\u00ae","\u2122","\u2713","[","]"
    };

    // ── Key Preview ───────────────────────────────────────────────────────
    private PopupWindow keyPreviewPopup;
    private final Handler previewHandler  = new Handler();
    private static final int PREVIEW_DISMISS_MS = 80;

    // ── Dot Popup ─────────────────────────────────────────────────────────
    private PopupWindow dotPopupWindow;

    // ── Choice Popup ──────────────────────────────────────────────────────
    private PopupWindow choicePopup;



    private void showChoicePopup(View anchor, String[] choices) {
        dismissChoicePopup();
        boolean dark = isDarkTheme();
        float dp     = getResources().getDisplayMetrics().density;
        int bgColor  = dark ? 0xFF2a2a2a : 0xFFFFFFFF;
        int txtColor = dark ? 0xFFEEEEEE : 0xFF111111;
        int cellW    = (int)(64 * dp);
        int cellH    = (int)(54 * dp);

        android.widget.LinearLayout row = new android.widget.LinearLayout(this);
        row.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        row.setPadding(8, 8, 8, 8);
        android.graphics.drawable.GradientDrawable popBg =
            new android.graphics.drawable.GradientDrawable();
        popBg.setColor(bgColor);
        popBg.setCornerRadius(12 * dp);
        popBg.setStroke(1, dark ? 0xFF444444 : 0xFFDDDDDD);
        row.setBackground(popBg);

        for (String ch : choices) {
            Button btn = new Button(this);
            btn.setText(ch);
            btn.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 22);
            btn.setTextColor(txtColor);
            btn.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            btn.setPadding(0, 0, 0, 0);
            android.graphics.drawable.GradientDrawable bd =
                new android.graphics.drawable.GradientDrawable();
            bd.setColor(dark ? 0xFF3a3a3a : 0xFFF5F5F5);
            bd.setCornerRadius(8 * dp);
            btn.setBackground(bd);
            android.widget.LinearLayout.LayoutParams lp =
                new android.widget.LinearLayout.LayoutParams(cellW, cellH);
            lp.setMargins(4, 0, 4, 0);
            btn.setLayoutParams(lp);
            btn.setOnClickListener(bv -> {
                InputConnection ic = getCurrentInputConnection();
                if (ic != null) ic.commitText(ch, 1);
                dismissChoicePopup();
            });
            row.addView(btn);
        }

        int popW = cellW * choices.length + 8 * (choices.length + 1) + 16;
        choicePopup = new PopupWindow(row, popW, cellH + 16, true);
        choicePopup.setBackgroundDrawable(
            new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        choicePopup.setElevation(20f);
        choicePopup.setOutsideTouchable(true);

        int[] loc = new int[2];
        anchor.getLocationInWindow(loc);
        int x = loc[0] + anchor.getWidth() / 2 - popW / 2;
        int y = loc[1] - cellH - 16 - (int)(8 * dp);
        try { choicePopup.showAtLocation(anchor, Gravity.NO_GRAVITY, x, y); }
        catch (Exception ignored) {}
    }

    private void dismissChoicePopup() {
        if (choicePopup != null && choicePopup.isShowing()) choicePopup.dismiss();
        choicePopup = null;
    }

    // ── Звук ──────────────────────────────────────────────────────────────
    private SoundPool soundPool;
    private int blipSoundId  = -1;
    private boolean soundLoaded = false;

    // ── Backspace hold ────────────────────────────────────────────────────
    private final Handler bsHandler = new Handler();
    private boolean bsHeld = false;
    private static final int BS_INITIAL = 400;
    private static final int BS_REPEAT  = 80;
    private final Runnable bsRunnable = new Runnable() {
        @Override public void run() {
            if (!bsHeld) return;
            InputConnection ic = getCurrentInputConnection();
            if (ic != null) ic.deleteSurroundingText(1, 0);
            bsHandler.postDelayed(this, BS_REPEAT);
        }
    };

    // ── Тема ──────────────────────────────────────────────────────────────
    private boolean isDarkTheme() {
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        return (hour >= 20 || hour < 8); // темна: 20:00–8:00
    }

    /** Повертає набір кольорів для поточної теми */
    private int[] themeColors() {
        if (isDarkTheme()) {
            // [bg, keyBg, keyPress, keyShadow, keyText, symText, serviceKey, globeText]
            return new int[]{
                0xFF1f1f1f, 0xFF2d2d2d, 0xFF3d3d3d, 0xFF111111,
                0xFFEEEEEE, 0xFFAAAAAA, 0xFF1a1a1a, 0xFFFFFFFF
            };
        } else {
            return new int[]{
                0xFFF0F4F9, 0xFFFFFFFF, 0xFFE0E0E0, 0xFFB0B8C0,
                0xFF111111, 0xFF222222, 0xFFD8DEE6, 0xFF000000
            };
        }
    }

    private void applyThemeToAlpha(View root) {
        if (root == null) return;
        int[] c = themeColors();
        root.setBackgroundColor(c[0]);

        // KeyButton-и
        for (int id : LETTER_IDS) {
            KeyButton kb = root.findViewById(id);
            if (kb != null) kb.applyTheme(c[1], c[2], c[3], c[4], c[5]);
        }
        for (int id : EXTRA_IDS) {
            KeyButton kb = root.findViewById(id);
            if (kb != null) kb.applyTheme(c[1], c[2], c[3], c[4], c[5]);
        }

        // Глобус — Button з Unicode символом 🌐
        Button langBtn = root.findViewById(R.id.a_lang);
        if (langBtn != null) {
            langBtn.setTextColor(c[7]); // чорний/білий по темі
            GradientDrawable langBg = new GradientDrawable();
            langBg.setColor(c[6]);
            langBg.setCornerRadius(5 * getResources().getDisplayMetrics().density);
            langBtn.setBackground(langBg);
        }

        // Службові кнопки — фон по темі
        int[] serviceIds = {
            R.id.a_shift, R.id.a_bs, R.id.a_to_sym, R.id.a_to_num,
            R.id.a_space, R.id.a_dot2, R.id.a_lang
        };
        for (int sid : serviceIds) {
            Button b = root.findViewById(sid);
            if (b != null) {
                GradientDrawable gd = new GradientDrawable();
                gd.setColor(c[6]);
                gd.setCornerRadius(5 * getResources().getDisplayMetrics().density);
                b.setBackground(gd);
                b.setTextColor(c[4]);
            }
        }
    }

    // ── Sound ─────────────────────────────────────────────────────────────
    private void initSound() {
        if (soundPool != null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            AudioAttributes attrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
            soundPool = new SoundPool.Builder().setMaxStreams(3)
                .setAudioAttributes(attrs).build();
        } else {
            soundPool = new SoundPool(3, android.media.AudioManager.STREAM_SYSTEM, 0);
        }
        soundPool.setOnLoadCompleteListener((sp, id, status) -> {
            if (status == 0) soundLoaded = true;
        });
        blipSoundId = soundPool.load(this, R.raw.blip, 1);
    }

    private void playBlip() {
        if (!getPrefs().getBoolean(KEY_SOUND_ENABLED, true)) return;
        if (soundPool != null && soundLoaded && blipSoundId != -1)
            soundPool.play(blipSoundId, 0.8f, 0.8f, 1, 0, 1.0f);
    }

    // ── Вібрація ──────────────────────────────────────────────────────────
    private void vibrate() {
        try {
            Vibrator vib = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (vib == null || !vib.hasVibrator()) return;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                vib.vibrate(VibrationEffect.createOneShot(40, 80));
            else
                vib.vibrate(40);
        } catch (Exception ignored) {}
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────
    @Override
    public View onCreateInputView() {
        isPinned    = getPrefs().getBoolean(KEY_PINNED, false);
        currentMode = getPrefs().getInt(KEY_LAST_MODE, MODE_NUM);
        initSound();
        return buildView(currentMode);
    }

    @Override
    public boolean onEvaluateInputViewShown() {
        // Завжди показуємо клавіатуру якщо є активне поле вводу
        return true;
    }

    @Override
    public boolean onEvaluateFullscreenMode() {
        //Ніколи не йдемо в fullscreen — клавіатура завжди знизу
        return false;
    }



    @Override
    public void onFinishInput() {
        super.onFinishInput();
        bsHeld = false;
        bsHandler.removeCallbacks(bsRunnable);
        dismissKeyPreview();
        dismissDotPopup();
        dismissChoicePopup();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (soundPool != null) { soundPool.release(); soundPool = null; }
    }

    // ── Nav padding ───────────────────────────────────────────────────────

    // ── Build views ───────────────────────────────────────────────────────
    private View buildView(int mode) {
        switch (mode) {
            case MODE_ALPHA: return buildAlphaView();
            case MODE_SYM:   return buildSymView();
            case MODE_SYM2:  return buildSym2View();
            default:         return buildNumView();
        }
    }

    private View buildNumView() {
        View v = LayoutInflater.from(this).inflate(R.layout.keyboard, null);
        final int rowH = getRowHeightPx();
        v.post(() -> applyGridRowHeight(v, rowH));

        int[] numIds = { R.id.btn_0,R.id.btn_1,R.id.btn_2,R.id.btn_3,R.id.btn_4,
                         R.id.btn_5,R.id.btn_6,R.id.btn_7,R.id.btn_8,R.id.btn_9 };
        for (int id : numIds) { Button b = v.findViewById(id); if (b!=null) b.setOnClickListener(this); }

        v.findViewById(R.id.btn_dot).setOnClickListener(this);
        v.findViewById(R.id.btn_dot).setOnLongClickListener(a -> { switchMode(MODE_ALPHA); return true; });
        setupBackspaceHold(v.findViewById(R.id.btn_backspace));
        v.findViewById(R.id.btn_backspace).setOnClickListener(this);

        Button wms = v.findViewById(R.id.btn_wms);
        wms.setOnClickListener(this);
        wms.setOnLongClickListener(a -> { togglePin(v); return true; });
        wms.setText(isPinned ? "wms \uD83D\uDCCC" : "wms");

        v.findViewById(R.id.btn_ok).setOnClickListener(this);
        v.findViewById(R.id.btn_ok).setOnLongClickListener(a -> { showImePicker(); return true; });

        applyTheme(v, getCurrentTheme());
        return v;
    }

    private View buildAlphaView() {
        View v = LayoutInflater.from(this).inflate(R.layout.keyboard_alpha, null);
        applyAlphaRowHeight(v);

        // ── Букви (KeyButton) ──
        for (int i = 0; i < LETTER_IDS.length; i++) {
            final int idx = i;
            KeyButton kb = v.findViewById(LETTER_IDS[i]);
            if (kb == null) continue;
            kb.setOnClickListener(this);

            // Key Preview
            kb.setOnTouchListener((vw, ev) -> {
                if (ev.getAction() == MotionEvent.ACTION_DOWN) {
                    String[] keys = LAYOUTS[currentLang];
                    String letter = idx < keys.length ? keys[idx] : "";
                    boolean up = (shiftState != SHIFT_OFF);
                    showKeyPreview(vw, up && !letter.isEmpty() ? letter.toUpperCase() : letter);
                } else if (ev.getAction() == MotionEvent.ACTION_UP
                        || ev.getAction() == MotionEvent.ACTION_CANCEL) {
                    previewHandler.postDelayed(this::dismissKeyPreview, PREVIEW_DISMISS_MS);
                }
                return false;
            });

            // Long press
            kb.setOnLongClickListener(a -> {
                InputConnection ic = getCurrentInputConnection();
                if (ic == null) return true;
                // е(4, UK) → popup ё / [  (тільки для UK)
                if (idx == 4 && currentLang == LANG_UK) {
                    boolean up = (shiftState != SHIFT_OFF);
                    showChoicePopup(kb, up
                        ? new String[]{"Ё", "["}
                        : new String[]{"ё", "["});
                    return true;
                }
                // і(11, UK) → popup ы / #
                if (idx == 11 && currentLang == LANG_UK) {
                    boolean up = (shiftState != SHIFT_OFF);
                    showChoicePopup(kb, up
                        ? new String[]{"Ы", "#"}
                        : new String[]{"ы", "#"});
                    return true;
                }
                // ь(25, UK) → одразу ?
                if (idx == 25 && currentLang == LANG_UK) {
                    ic.commitText("?", 1);
                    return true;
                }
                // Решта — popup зі спецсимволом
                if (idx < KEY_SYMBOLS.length && !KEY_SYMBOLS[idx].isEmpty()) {
                    String sym = KEY_SYMBOLS[idx];
                    // UK: d(idx=12) → ₴
                    if (idx == 12 && currentLang == LANG_UK) sym = "\u20b4";
                    showChoicePopup(kb, new String[]{sym});
                }
                return true;
            });
        }

        // ── Extra (UK додаткові букви) ──
        for (int i = 0; i < EXTRA_IDS.length; i++) {
            final int extraI = i;
            KeyButton kb = v.findViewById(EXTRA_IDS[i]);
            if (kb == null) continue;
            kb.setOnClickListener(this);
            kb.setOnLongClickListener(a -> {
                int layoutIdx = EXTRA_LAYOUT_IDX[extraI];
                handleExtraLongPress(kb, layoutIdx);
                return true;
            });
        }

        // ── Цифри верхнього ряду ──
        for (int id : ALPHA_NUM_IDS) { Button b = v.findViewById(id); if (b!=null) b.setOnClickListener(this); }

        // ── Службові ──
        v.findViewById(R.id.a_shift).setOnClickListener(this);

        // Крапка → popup замість одиночного символу
        View dot = v.findViewById(R.id.a_dot2);
        dot.setOnClickListener(this);
        dot.setOnLongClickListener(a -> { showDotPopup(dot); return true; });


        v.findViewById(R.id.a_ok).setOnClickListener(this);
        v.findViewById(R.id.a_ok).setOnLongClickListener(a -> { showImePicker(); return true; });
        v.findViewById(R.id.a_to_sym).setOnClickListener(this);
        v.findViewById(R.id.a_to_num).setOnClickListener(this);

        Button langBtn2 = v.findViewById(R.id.a_lang);
        if (langBtn2 != null) {
            langBtn2.setOnClickListener(vv -> {
                currentLang = (currentLang + 1) % LAYOUTS.length;
                switchMode(MODE_ALPHA);
            });
            langBtn2.setOnLongClickListener(a -> { showImePicker(); return true; });
        }

        Button spaceBtn = v.findViewById(R.id.a_space);
        spaceBtn.setOnClickListener(this);
        spaceBtn.setOnLongClickListener(a -> {
            currentLang = (currentLang + 1) % LAYOUTS.length;
            switchMode(MODE_ALPHA); return true;
        });

        setupBackspaceHold(v.findViewById(R.id.a_bs));

        applyAlphaLabels(v);
        applyThemeToAlpha(v);
        return v;
    }

    /** Повертає альтернативну букву при довгому натисканні, або null */
    private String getLongPressAlt(int idx) {
        // Логіка перенесена в long-press handler в buildAlphaView
        return null;
    }

    /** long-press для extra кнопок */
    private void handleExtraLongPress(View anchor, int layoutIdx) {
        InputConnection ic = getCurrentInputConnection();
        // є(28) → popup [э, ~]
        if (layoutIdx == 28 && currentLang == LANG_UK) {
            showChoicePopup(anchor, new String[]{"э", "~"});
            return;
        }
        // б(29) → \
        if (layoutIdx == 29) { if (ic != null) ic.commitText("\\", 1); return; }
        // ю(30) → %
        if (layoutIdx == 30) { if (ic != null) ic.commitText("%", 1); return; }
        // ґ(32) → ^
        if (layoutIdx == 32) { if (ic != null) ic.commitText("^", 1); return; }
    }

    private View buildSymView() {
        View v = LayoutInflater.from(this).inflate(R.layout.keyboard_sym, null);
        for (int id : SYM_IDS) { Button b = v.findViewById(id); if (b!=null) b.setOnClickListener(this); }
        for (int id : SYM_NUM_IDS) { Button b = v.findViewById(id); if (b!=null) b.setOnClickListener(this); }
        v.findViewById(R.id.s_to_alpha).setOnClickListener(this);
        v.findViewById(R.id.s_to_sym2).setOnClickListener(this);
        v.findViewById(R.id.s_space).setOnClickListener(this);
        v.findViewById(R.id.s_comma).setOnClickListener(this);
        v.findViewById(R.id.s_dot).setOnClickListener(this);
        v.findViewById(R.id.s_ok).setOnClickListener(this);
        v.findViewById(R.id.s_ok).setOnLongClickListener(a -> { showImePicker(); return true; });
        setupBackspaceHold(v.findViewById(R.id.s_bs));
        return v;
    }

    private View buildSym2View() {
        View v = LayoutInflater.from(this).inflate(R.layout.keyboard_sym2, null);
        for (int id : SYM2_IDS) { Button b = v.findViewById(id); if (b!=null) b.setOnClickListener(this); }
        v.findViewById(R.id.s2_to_alpha).setOnClickListener(this);
        v.findViewById(R.id.s2_to_sym).setOnClickListener(this);
        v.findViewById(R.id.s2_space).setOnClickListener(this);
        v.findViewById(R.id.s2_lt).setOnClickListener(this);
        v.findViewById(R.id.s2_gt).setOnClickListener(this);
        v.findViewById(R.id.s2_ok).setOnClickListener(this);
        v.findViewById(R.id.s2_ok).setOnLongClickListener(a -> { showImePicker(); return true; });
        setupBackspaceHold(v.findViewById(R.id.s2_bs));
        return v;
    }

    private void switchMode(int mode) {
        currentMode = mode;
        getPrefs().edit().putInt(KEY_LAST_MODE, mode).apply();
        setInputView(buildView(mode));
    }

    private void togglePin(View numView) {
        isPinned = !isPinned;
        getPrefs().edit().putBoolean(KEY_PINNED, isPinned).apply();
        Toast.makeText(this, isPinned ? "\u0417\u0430\u043a\u0440\u0435\u043f\u043b\u0435\u043d\u043e \uD83D\uDCCC"
                                      : "\u0420\u0430\u0437\u043a\u0440\u0435\u043f\u043b\u0435\u043d\u043e",
                Toast.LENGTH_SHORT).show();
        Button wms = numView.findViewById(R.id.btn_wms);
        if (wms != null) wms.setText(isPinned ? "wms \uD83D\uDCCC" : "wms");
    }

    // ── Мітки букв ────────────────────────────────────────────────────────
    private void applyAlphaLabels(View root) {
        if (root == null) return;
        String[] keys   = LAYOUTS[currentLang];
        boolean upper   = (shiftState != SHIFT_OFF);
        boolean isLatin = (currentLang == LANG_EN);

        for (int i = 0; i < LETTER_IDS.length && i < 26; i++) {
            KeyButton kb = root.findViewById(LETTER_IDS[i]);
            if (kb == null) continue;
            String letter = i < keys.length ? keys[i] : "";
            String sym    = (i < KEY_SYMBOLS.length) ? KEY_SYMBOLS[i] : "";
            // UK: d(idx=12) → ₴ замість $
            if (i == 12 && currentLang == LANG_UK) sym = "\u20b4";
            // Для RU: позиція 11 (де була Ы) — пуста
            if (letter.isEmpty()) { kb.setContent("", ""); kb.setVisibility(View.GONE); continue; }
            kb.setVisibility(View.VISIBLE);
            String disp = (upper && !letter.isEmpty()) ? letter.toUpperCase() : letter;
            kb.setContent(disp, sym);
        }

        // Extra кнопки (RU/UK специфічні)
        for (int i = 0; i < EXTRA_IDS.length; i++) {
            KeyButton kb = root.findViewById(EXTRA_IDS[i]);
            if (kb == null) continue;
            int layoutIdx = EXTRA_LAYOUT_IDX[i];
            String letter = layoutIdx < keys.length ? keys[layoutIdx] : "";
            if (isLatin || letter.isEmpty()) {
                kb.setVisibility(View.GONE);
            } else {
                kb.setVisibility(View.VISIBLE);
                // Символ для extra кнопок: б→\, ю→%, ґ→^
                String extraSym = "";
                if (layoutIdx == 29) extraSym = "\\";
                else if (layoutIdx == 30) extraSym = "%";
                else if (layoutIdx == 32) extraSym = "^";
                kb.setContent(upper ? letter.toUpperCase() : letter, extraSym);
            }
        }

        Button spaceBtn = root.findViewById(R.id.a_space);
        if (spaceBtn != null) spaceBtn.setText(LANG_LABELS[currentLang]);
    }

    // ── Key Preview ───────────────────────────────────────────────────────
    private void showKeyPreview(View anchor, String label) {
        if (label == null || label.isEmpty()) return;
        dismissKeyPreview();

        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 30);
        tv.setTextColor(isDarkTheme() ? 0xFFEEEEEE : 0xFF111111);
        tv.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(24, 10, 24, 10);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(isDarkTheme() ? 0xFF3d3d3d : 0xFFFFFFFF);
        bg.setCornerRadius(14f);
        bg.setStroke(1, isDarkTheme() ? 0xFF555555 : 0xFFCCCCCC);
        tv.setBackground(bg);

        float dp = getResources().getDisplayMetrics().density;
        int w = (int)(52 * dp), h = (int)(56 * dp);

        keyPreviewPopup = new PopupWindow(tv, w, h, false);
        keyPreviewPopup.setBackgroundDrawable(null);
        keyPreviewPopup.setElevation(16f);

        int[] loc = new int[2];
        anchor.getLocationInWindow(loc);
        int x = loc[0] + anchor.getWidth() / 2 - w / 2;
        int y = loc[1] - h - (int)(4 * dp);
        try { keyPreviewPopup.showAtLocation(anchor, Gravity.NO_GRAVITY, x, y); }
        catch (Exception ignored) {}
    }

    private void dismissKeyPreview() {
        previewHandler.removeCallbacksAndMessages(null);
        if (keyPreviewPopup != null && keyPreviewPopup.isShowing())
            keyPreviewPopup.dismiss();
        keyPreviewPopup = null;
    }

    // ── Dot Popup (красивий грід символів) ───────────────────────────────
    private void showDotPopup(View anchor) {
        dismissDotPopup();
        dismissChoicePopup();

        boolean dark = isDarkTheme();
        int bgColor  = dark ? 0xFF2a2a2a : 0xFFFFFFFF;
        int txtColor = dark ? 0xFFEEEEEE : 0xFF111111;

        // Контейнер
        android.widget.GridLayout grid = new android.widget.GridLayout(this);
        grid.setColumnCount(4);
        grid.setBackgroundColor(bgColor);
        grid.setPadding(12, 12, 12, 12);

        float dp = getResources().getDisplayMetrics().density;
        int cellW = (int)(64 * dp), cellH = (int)(52 * dp);

        for (int i = 0; i < DOT_POPUP_SYMBOLS.length; i++) {
            final String sym = DOT_POPUP_SYMBOLS[i];
            Button btn = new Button(this);
            btn.setText(sym);
            btn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
            btn.setTextColor(txtColor);
            btn.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            btn.setPadding(0, 0, 0, 0);

            GradientDrawable bd = new GradientDrawable();
            bd.setColor(dark ? 0xFF3a3a3a : 0xFFF5F5F5);
            bd.setCornerRadius(6 * dp);
            btn.setBackground(bd);

            android.widget.GridLayout.LayoutParams lp =
                new android.widget.GridLayout.LayoutParams();
            lp.width  = cellW;
            lp.height = cellH;
            lp.setMargins(4, 4, 4, 4);
            btn.setLayoutParams(lp);

            btn.setOnClickListener(bv -> {
                InputConnection ic = getCurrentInputConnection();
                if (ic != null) ic.commitText(sym, 1);
                dismissDotPopup();
        dismissChoicePopup();
            });
            grid.addView(btn);
        }

        // Скруглення попапу
        GradientDrawable popupBg = new GradientDrawable();
        popupBg.setColor(bgColor);
        popupBg.setCornerRadius(10 * dp);
        popupBg.setStroke(1, dark ? 0xFF444444 : 0xFFDDDDDD);
        grid.setBackground(popupBg);

        int popW = cellW * 4 + 8 * 4 + 24;
        int popH = cellH * (DOT_POPUP_SYMBOLS.length / 4) + 8 * (DOT_POPUP_SYMBOLS.length / 4) + 24;

        dotPopupWindow = new PopupWindow(grid, popW, popH, true);
        dotPopupWindow.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        dotPopupWindow.setElevation(20f);
        dotPopupWindow.setOutsideTouchable(true);

        int[] loc = new int[2];
        anchor.getLocationInWindow(loc);
        int x = loc[0] + anchor.getWidth() / 2 - popW / 2;
        int y = loc[1] - popH - (int)(8 * dp);
        try { dotPopupWindow.showAtLocation(anchor, Gravity.NO_GRAVITY, x, y); }
        catch (Exception ignored) {}
    }

    private void dismissDotPopup() {
        if (dotPopupWindow != null && dotPopupWindow.isShowing())
            dotPopupWindow.dismiss();
        dotPopupWindow = null;
    }

    private void showImePicker() {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.showInputMethodPicker();
    }

    // ── Висота рядків ─────────────────────────────────────────────────────
    private int getRowHeightPx() {
        int dp = getPrefs().getInt(KEY_ROW_HEIGHT, DEFAULT_ROW_HEIGHT);
        return (int) TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, dp, getResources().getDisplayMetrics());
    }

    private void applyGridRowHeight(View root, int rowH) {
        GridLayout grid = root.findViewById(R.id.grid_num);
        if (grid == null) return;
        int gap = (int) TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, 6, getResources().getDisplayMetrics());
        for (int i = 0; i < grid.getChildCount(); i++) {
            View child = grid.getChildAt(i);
            GridLayout.LayoutParams lp = (GridLayout.LayoutParams) child.getLayoutParams();
            int rowSpan = 1;
            Object tag = child.getTag();
            if (tag != null) {
                try { rowSpan = Integer.parseInt(tag.toString()); } catch (Exception ignored) {}
            }
            lp.height = rowH * rowSpan + (rowSpan > 1 ? gap : 0);
            child.setLayoutParams(lp);
        }
        grid.requestLayout();
    }

    private void applyAlphaRowHeight(View root) {
        int dp = getPrefs().getInt(KEY_ALPHA_ROW_HEIGHT, DEFAULT_ALPHA_ROW_HEIGHT);
        int px = (int) TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, dp, getResources().getDisplayMetrics());
        if (!(root instanceof ViewGroup)) return;
        ViewGroup vg = (ViewGroup) root;
        for (int i = 0; i < vg.getChildCount(); i++) {
            View child = vg.getChildAt(i);
            if (child instanceof android.widget.LinearLayout) {
                android.widget.LinearLayout row = (android.widget.LinearLayout) child;
                if (row.getOrientation() == android.widget.LinearLayout.HORIZONTAL) {
                    ViewGroup.LayoutParams lp = row.getLayoutParams();
                    if (lp != null && lp.height > 0) { lp.height = px; row.setLayoutParams(lp); }
                }
            }
        }
    }

    // ── Тема числової ─────────────────────────────────────────────────────
    private Theme getCurrentTheme() {
        return Theme.findById(getPrefs().getString("theme_id", "blue"));
    }

    private android.graphics.drawable.Drawable makeDrawable(int normal, int pressed) {
        GradientDrawable n = new GradientDrawable(); n.setColor(normal);  n.setCornerRadius(12f);
        GradientDrawable p = new GradientDrawable(); p.setColor(pressed); p.setCornerRadius(12f);
        StateListDrawable sl = new StateListDrawable();
        sl.addState(new int[]{android.R.attr.state_pressed}, p);
        sl.addState(new int[]{}, n);
        return sl;
    }

    private void applyTheme(View root, Theme t) {
        if (root == null || t == null) return;
        root.setBackgroundColor(t.background);
        applyThemeGroup((ViewGroup) root, t);
    }

    private void applyThemeGroup(ViewGroup vg, Theme t) {
        for (int i = 0; i < vg.getChildCount(); i++) {
            View child = vg.getChildAt(i);
            if (child instanceof ViewGroup) {
                child.setBackgroundColor(t.background);
                applyThemeGroup((ViewGroup) child, t);
            } else if (child instanceof Button) {
                Button btn = (Button) child;
                int id = btn.getId();
                if (id == R.id.btn_wms) continue;
                if (id == R.id.btn_ok)
                    btn.setBackground(makeDrawable(t.btnOkNormal, t.btnOkPressed));
                else if (id == R.id.btn_backspace || id == R.id.btn_dot)
                    btn.setBackground(makeDrawable(t.btnDarkNormal, t.btnDarkPressed));
                else {
                    btn.setTextColor(t.textColor);
                    btn.setBackground(makeDrawable(t.btnMainNormal, t.btnMainPressed));
                }
            }
        }
    }

    // ── Backspace hold ────────────────────────────────────────────────────
    private void setupBackspaceHold(View btn) {
        if (btn == null) return;
        btn.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    bsHeld = true;
                    InputConnection ic = getCurrentInputConnection();
                    if (ic != null) ic.deleteSurroundingText(1, 0);
                    bsHandler.postDelayed(bsRunnable, BS_INITIAL);
                    v.setPressed(true);
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    bsHeld = false;
                    bsHandler.removeCallbacks(bsRunnable);
                    v.setPressed(false);
                    return true;
            }
            return false;
        });
    }

    // ── Enter ─────────────────────────────────────────────────────────────
    private void doEnter() { sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER); }

    @Override
    public void onStartInput(EditorInfo attribute, boolean restarting) {
        super.onStartInput(attribute, restarting);
        shiftState = SHIFT_OFF;
    }

    // ── onClick ───────────────────────────────────────────────────────────
    @Override
    public void onClick(View v) {
        int id = v.getId();

        // WMS
        if (id == R.id.btn_wms) {
            vibrate(); playBlip();
            InputConnection ic = getCurrentInputConnection();
            if (ic != null) ic.commitText(WMS_TEXT, 1);
            doEnter(); return;
        }

        // Режими
        if (id == R.id.a_to_num)  { switchMode(MODE_NUM);   return; }
        if (id == R.id.a_to_sym)  { switchMode(MODE_SYM);   return; }
        if (id == R.id.s_to_alpha || id == R.id.s2_to_alpha) { switchMode(MODE_ALPHA); return; }
        if (id == R.id.s_to_sym2) { switchMode(MODE_SYM2);  return; }
        if (id == R.id.s2_to_sym) { switchMode(MODE_SYM);   return; }
        if (id == R.id.s_space)   { switchMode(MODE_SYM);   return; }

        // Мова (обробляється через langBtn2.setOnClickListener вище)

        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;

        // Shift
        if (id == R.id.a_shift) {
            if      (shiftState == SHIFT_OFF)  shiftState = SHIFT_ONE;
            else if (shiftState == SHIFT_ONE)  shiftState = SHIFT_CAPS;
            else                               shiftState = SHIFT_OFF;
            switchMode(MODE_ALPHA); return;
        }

        // Enter
        if (id == R.id.btn_ok) { vibrate(); playBlip(); doEnter(); return; }
        if (id == R.id.a_ok || id == R.id.s_ok || id == R.id.s2_ok) { doEnter(); return; }

        // Backspace (одиночний)
        if (id == R.id.btn_backspace) { ic.deleteSurroundingText(1, 0); return; }

        // Крапка / пробіл
        if (id == R.id.btn_dot || id == R.id.a_dot2 || id == R.id.s_dot)
            { ic.commitText(".", 1); return; }
        if (id == R.id.s_comma) { ic.commitText(",", 1); return; }
        if (id == R.id.a_space || id == R.id.s2_space) { ic.commitText(" ", 1); return; }
        if (id == R.id.s2_lt) { ic.commitText("<", 1); return; }
        if (id == R.id.s2_gt) { ic.commitText(">", 1); return; }

        // Цифри числової
        int[] numIds = { R.id.btn_0,R.id.btn_1,R.id.btn_2,R.id.btn_3,R.id.btn_4,
                         R.id.btn_5,R.id.btn_6,R.id.btn_7,R.id.btn_8,R.id.btn_9 };
        for (int nid : numIds) {
            if (id == nid) { vibrate(); playBlip();
                ic.commitText(((Button)v).getText().toString(), 1); return; }
        }

        // Цифри верхніх рядів
        for (int nid : ALPHA_NUM_IDS) { if (id == nid) { ic.commitText(((Button)v).getText().toString(),1); return; } }
        for (int nid : SYM_NUM_IDS)   { if (id == nid) { ic.commitText(((Button)v).getText().toString(),1); return; } }

        // Символи SYM / SYM2
        for (int i = 0; i < SYM_IDS.length;  i++) { if (id == SYM_IDS[i])  { ic.commitText(SYM_VALS[i],  1); return; } }
        for (int i = 0; i < SYM2_IDS.length; i++) { if (id == SYM2_IDS[i]) { ic.commitText(SYM2_VALS[i], 1); return; } }

        // Extra букви (RU/UK)
        for (int i = 0; i < EXTRA_IDS.length; i++) {
            if (id == EXTRA_IDS[i]) {
                String[] keys = LAYOUTS[currentLang];
                int idx = EXTRA_LAYOUT_IDX[i];
                String letter = idx < keys.length ? keys[idx] : "";
                if (!letter.isEmpty()) {
                    boolean upper = (shiftState != SHIFT_OFF);
                    ic.commitText(upper ? letter.toUpperCase() : letter, 1);
                    if (shiftState == SHIFT_ONE) { shiftState = SHIFT_OFF; switchMode(MODE_ALPHA); }
                }
                return;
            }
        }

        // Букви (KeyButton)
        for (int i = 0; i < LETTER_IDS.length; i++) {
            if (id == LETTER_IDS[i]) {
                String[] keys = LAYOUTS[currentLang];
                boolean upper = (shiftState != SHIFT_OFF);
                String letter = i < keys.length ? keys[i] : "";
                if (letter.isEmpty()) return;
                ic.commitText(upper ? letter.toUpperCase() : letter, 1);
                if (shiftState == SHIFT_ONE) { shiftState = SHIFT_OFF; switchMode(MODE_ALPHA); }
                return;
            }
        }
    }

    private SharedPreferences getPrefs() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
    }
}

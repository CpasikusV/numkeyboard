package com.numkey.ime;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.View;

/**
 * Кнопка клавіатури:
 *  - буква по центру (великий, жирний)
 *  - спецсимвол у верхньому ПРАВОМУ куті (маленький, сірий)
 *  - тінь знизу (темний шар)
 *  - скруглення 5dp
 *  - ripple при натисканні (зміна кольору)
 */
public class KeyButton extends View {

    private String letter  = "";
    private String symbol  = "";

    private final Paint letterPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint symbolPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bgPaint     = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint shadowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF bgRect      = new RectF();
    private final RectF shadowRect  = new RectF();

    private int bgNormalColor   = 0xFFFFFFFF;
    private int bgPressedColor  = 0xFFDDDDDD;
    private int shadowColor     = 0xFFB0B0B0;
    private int letterColor     = 0xFF111111;
    private int symbolColor     = 0xFF999999;
    private boolean pressed_    = false;
    private float cornerRadius  = 0f;
    private float shadowHeight  = 0f;

    public KeyButton(Context context) { super(context); init(); }
    public KeyButton(Context context, AttributeSet a) { super(context, a); init(); }
    public KeyButton(Context context, AttributeSet a, int d) { super(context, a, d); init(); }

    private void init() {
        letterPaint.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        letterPaint.setTextAlign(Paint.Align.CENTER);

        symbolPaint.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        symbolPaint.setTextAlign(Paint.Align.RIGHT);

        setClickable(true);
        setLongClickable(true);

        // конвертуємо dp → px
        float density = getResources().getDisplayMetrics().density;
        cornerRadius = 5f * density;
        shadowHeight = 2f * density;
    }

    /** Встановити букву та символ разом */
    public void setContent(String letter, String symbol) {
        this.letter = letter != null ? letter : "";
        this.symbol = symbol != null ? symbol : "";
        invalidate();
    }

    public void setLetter(String l) { this.letter = l != null ? l : ""; invalidate(); }
    public void setSymbol(String s) { this.symbol = s != null ? s : ""; invalidate(); }
    public String getLetter() { return letter; }

    /**
     * Задати кольори для теми.
     * @param bg      колір кнопки (нормальний)
     * @param bgPress колір при натисканні
     * @param shadow  колір тіні знизу
     * @param text    колір букви
     * @param sym     колір спецсимволу
     */
    public void applyTheme(int bg, int bgPress, int shadow, int text, int sym) {
        bgNormalColor  = bg;
        bgPressedColor = bgPress;
        shadowColor    = shadow;
        letterColor    = text;
        symbolColor    = sym;  // передається ззовні
        letterPaint.setColor(text);
        symbolPaint.setColor(sym);
        invalidate();
    }

    @Override
    public void setPressed(boolean pressed) {
        super.setPressed(pressed);
        pressed_ = pressed;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int w = getWidth();
        int h = getHeight();
        float m = 3f;

        // ── Основний фон (без тіні) ──
        bgPaint.setColor(pressed_ ? bgPressedColor : bgNormalColor);
        bgRect.set(m, m, w - m, h - m);
        canvas.drawRoundRect(bgRect, cornerRadius, cornerRadius, bgPaint);

        float usableH = h - m * 2;
        float top = m;

        // ── Буква по центру ──
        if (!letter.isEmpty()) {
            float letterSize = usableH * 0.52f;
            letterPaint.setTextSize(letterSize);
            float centerX = w / 2f;
            float centerY = top + usableH / 2f
                    - (letterPaint.descent() + letterPaint.ascent()) / 2f;
            canvas.drawText(letter, centerX, centerY, letterPaint);
        }

        // ── Спецсимвол — верхній правий кут ──
        if (!symbol.isEmpty()) {
            float symSize = usableH * 0.22f;
            symbolPaint.setTextSize(symSize);
            float symX = w - m - 6f;
            float symY = top + symSize + 4f;
            canvas.drawText(symbol, symX, symY, symbolPaint);
        }
    }
}

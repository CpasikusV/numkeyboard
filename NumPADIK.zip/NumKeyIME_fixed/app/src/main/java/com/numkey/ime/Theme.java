package com.numkey.ime;

/**
 * Цветовая схема клавиатуры.
 * Каждая тема задаёт цвета для 4 типов кнопок + фон + цвет текста.
 */
public class Theme {
    public final String id;
    public final String name;

    // Основные кнопки (цифры/буквы) — normal и pressed
    public final int btnMainNormal;
    public final int btnMainPressed;

    // Служебные кнопки (тёмные: ⌫, ., пробел)
    public final int btnDarkNormal;
    public final int btnDarkPressed;

    // OK
    public final int btnOkNormal;
    public final int btnOkPressed;

    // C (clear)
    public final int btnRedNormal;
    public final int btnRedPressed;

    // Фон клавиатуры
    public final int background;

    // Цвет текста на кнопках
    public final int textColor;

    public Theme(String id, String name,
                 int btnMainNormal, int btnMainPressed,
                 int btnDarkNormal, int btnDarkPressed,
                 int btnOkNormal,   int btnOkPressed,
                 int btnRedNormal,  int btnRedPressed,
                 int background,    int textColor) {
        this.id             = id;
        this.name           = name;
        this.btnMainNormal  = btnMainNormal;
        this.btnMainPressed = btnMainPressed;
        this.btnDarkNormal  = btnDarkNormal;
        this.btnDarkPressed = btnDarkPressed;
        this.btnOkNormal    = btnOkNormal;
        this.btnOkPressed   = btnOkPressed;
        this.btnRedNormal   = btnRedNormal;
        this.btnRedPressed  = btnRedPressed;
        this.background     = background;
        this.textColor      = textColor;
    }

    // ── Все доступные темы ────────────────────────────────────────────────
    public static final Theme[] ALL = {

        new Theme("blue", "Синяя",
            0xFF1E88E5, 0xFF1565C0,   // main
            0xFF616161, 0xFF424242,   // dark
            0xFF43A047, 0xFF2E7D32,   // ok
            0xFFE53935, 0xFFC62828,   // red
            0xFF2D2D2D, 0xFFFFFFFF),  // bg, text

        new Theme("light_grey", "Светло-серая",
            0xFF90A4AE, 0xFF607D8B,   // main
            0xFFB0BEC5, 0xFF90A4AE,   // dark
            0xFF66BB6A, 0xFF388E3C,   // ok
            0xFFEF5350, 0xFFC62828,   // red
            0xFFECEFF1, 0xFF212121),  // bg, text

        new Theme("dark_grey", "Тёмно-серая",
            0xFF455A64, 0xFF37474F,   // main
            0xFF546E7A, 0xFF455A64,   // dark
            0xFF43A047, 0xFF2E7D32,   // ok
            0xFFE53935, 0xFFC62828,   // red
            0xFF263238, 0xFFFFFFFF),  // bg, text

        new Theme("dark_pink", "Тёмно-розовая",
            0xFFC2185B, 0xFF880E4F,   // main
            0xFFAD1457, 0xFF880E4F,   // dark
            0xFF43A047, 0xFF2E7D32,   // ok
            0xFFD81B60, 0xFF880E4F,   // red
            0xFF4A0030, 0xFFFFFFFF),  // bg, text

        new Theme("orange", "Оранжевая",
            0xFFF4511E, 0xFFBF360C,   // main
            0xFFFF7043, 0xFFE64A19,   // dark
            0xFF43A047, 0xFF2E7D32,   // ok
            0xFFE53935, 0xFFC62828,   // red
            0xFF3E1A00, 0xFFFFFFFF),  // bg, text

        new Theme("dark_green", "Тёмно-зелёная",
            0xFF2E7D32, 0xFF1B5E20,   // main
            0xFF388E3C, 0xFF2E7D32,   // dark
            0xFF1565C0, 0xFF0D47A1,   // ok (синий для контраста)
            0xFFE53935, 0xFFC62828,   // red
            0xFF1A2E1A, 0xFFFFFFFF),  // bg, text

        new Theme("light_blue", "Светло-голубая",
            0xFF4FC3F7, 0xFF0288D1,   // main
            0xFF81D4FA, 0xFF4FC3F7,   // dark
            0xFF66BB6A, 0xFF388E3C,   // ok
            0xFFEF5350, 0xFFC62828,   // red
            0xFFE1F5FE, 0xFF212121),  // bg, text

        new Theme("black", "Чёрная",
            0xFF212121, 0xFF000000,   // main
            0xFF303030, 0xFF212121,   // dark
            0xFF1B5E20, 0xFF003300,   // ok
            0xFFB71C1C, 0xFF7F0000,   // red
            0xFF000000, 0xFFFFFFFF),  // bg, text

        // iOS стиль: білі цифри, сірі службові, світло-сірий фон
        new Theme("ios", "iOS",
            0xFFFFFFFF, 0xFFC8CDD5,   // main: білі цифри
            0xFFADB5BD, 0xFFFFFFFF,   // dark: сірі службові
            0xFFADB5BD, 0xFFFFFFFF,   // ok: теж сірий (як ↵ на скріні)
            0xFFADB5BD, 0xFF8A9BB0,   // red
            0xFFD1D5DB, 0xFF111111),  // bg: #D1D5DB, text: чорний
    };

    public static Theme findById(String id) {
        for (Theme t : ALL) {
            if (t.id.equals(id)) return t;
        }
        return ALL[0]; // default: blue
    }
}

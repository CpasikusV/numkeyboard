package com.numkey.ime;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

public class SettingsActivity extends Activity {

    private SharedPreferences prefs;
    private SeekBar seekBarNum;
    private SeekBar seekBarAlpha;
    private TextView tvNumValue;
    private TextView tvAlphaValue;
    private TextView tvCurrentTheme;
    private String selectedThemeId;
    private Switch switchSound;

    private static final int[] THEME_BTN_IDS = {
        R.id.theme_blue, R.id.theme_light_grey, R.id.theme_dark_grey,
        R.id.theme_dark_pink, R.id.theme_orange, R.id.theme_dark_green,
        R.id.theme_light_blue, R.id.theme_black, R.id.theme_ios
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        prefs          = getSharedPreferences(NumKeyIMEService.PREFS_NAME, MODE_PRIVATE);
        seekBarNum     = findViewById(R.id.seekbar_height);
        seekBarAlpha   = findViewById(R.id.seekbar_alpha_height);
        tvNumValue     = findViewById(R.id.tv_height_value);
        tvAlphaValue   = findViewById(R.id.tv_alpha_height_value);
        tvCurrentTheme = findViewById(R.id.tv_current_theme);
        switchSound    = findViewById(R.id.switch_sound);
        selectedThemeId = prefs.getString("theme_id", "blue");

        // Звук
        switchSound.setChecked(prefs.getBoolean(NumKeyIMEService.KEY_SOUND_ENABLED, true));

        // Числовая высота
        int savedNum = prefs.getInt(NumKeyIMEService.KEY_ROW_HEIGHT, NumKeyIMEService.DEFAULT_ROW_HEIGHT);
        seekBarNum.setProgress(savedNum);
        tvNumValue.setText(savedNum + " dp");
        seekBarNum.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean u) { tvNumValue.setText(p + " dp"); }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        });

        // Буквенная высота
        int savedAlpha = prefs.getInt(NumKeyIMEService.KEY_ALPHA_ROW_HEIGHT, NumKeyIMEService.DEFAULT_ALPHA_ROW_HEIGHT);
        seekBarAlpha.setProgress(savedAlpha);
        tvAlphaValue.setText(savedAlpha + " dp");
        seekBarAlpha.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean u) { tvAlphaValue.setText(p + " dp"); }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        });

        // Темы
        updateThemeLabel();
        for (int btnId : THEME_BTN_IDS) {
            Button btn = findViewById(btnId);
            if (btn == null) continue;
            btn.setOnClickListener(v -> {
                String themeId = getThemeIdForButton(v.getId());
                if (themeId != null) {
                    selectedThemeId = themeId;
                    updateThemeLabel();
                    highlightSelected(v.getId());
                }
            });
        }
        highlightSelected(getButtonIdForTheme(selectedThemeId));

        // Сохранить
        Button btnSave = findViewById(R.id.btn_save);
        btnSave.setOnClickListener(v -> {
            prefs.edit()
                .putInt(NumKeyIMEService.KEY_ROW_HEIGHT, seekBarNum.getProgress())
                .putInt(NumKeyIMEService.KEY_ALPHA_ROW_HEIGHT, seekBarAlpha.getProgress())
                .putString("theme_id", selectedThemeId)
                .putBoolean(NumKeyIMEService.KEY_SOUND_ENABLED, switchSound.isChecked())
                .apply();
            finish();
        });
    }

    private String getThemeIdForButton(int btnId) {
        if (btnId == R.id.theme_blue)       return "blue";
        if (btnId == R.id.theme_light_grey) return "light_grey";
        if (btnId == R.id.theme_dark_grey)  return "dark_grey";
        if (btnId == R.id.theme_dark_pink)  return "dark_pink";
        if (btnId == R.id.theme_orange)     return "orange";
        if (btnId == R.id.theme_dark_green) return "dark_green";
        if (btnId == R.id.theme_light_blue) return "light_blue";
        if (btnId == R.id.theme_black)      return "black";
        if (btnId == R.id.theme_ios)        return "ios";
        return null;
    }

    private int getButtonIdForTheme(String themeId) {
        switch (themeId) {
            case "light_grey":  return R.id.theme_light_grey;
            case "dark_grey":   return R.id.theme_dark_grey;
            case "dark_pink":   return R.id.theme_dark_pink;
            case "orange":      return R.id.theme_orange;
            case "dark_green":  return R.id.theme_dark_green;
            case "light_blue":  return R.id.theme_light_blue;
            case "black":       return R.id.theme_black;
            case "ios":         return R.id.theme_ios;
            default:            return R.id.theme_blue;
        }
    }

    private void updateThemeLabel() {
        Theme t = Theme.findById(selectedThemeId);
        tvCurrentTheme.setText("Выбрана: " + t.name);
    }

    private void highlightSelected(int selectedBtnId) {
        for (int btnId : THEME_BTN_IDS) {
            Button btn = findViewById(btnId);
            if (btn == null) continue;
            if (btnId == selectedBtnId) {
                btn.setAlpha(1.0f);
                btn.setScaleX(1.05f);
                btn.setScaleY(1.05f);
            } else {
                btn.setAlpha(0.7f);
                btn.setScaleX(1.0f);
                btn.setScaleY(1.0f);
            }
        }
    }
}

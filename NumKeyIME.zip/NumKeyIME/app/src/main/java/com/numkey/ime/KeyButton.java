package com.numkey.ime;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;

/**
 * Кнопка клавиатуры с буквой по центру и маленьким спецсимволом в правом верхнем углу.
 * Символ занимает ~7% высоты кнопки.
 */
public class KeyButton extends View {

    private String letter = "";
    private String symbol = "";

    private final Paint letterPaint  = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint symbolPaint  = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bgPaint      = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF bgRect       = new RectF();

    private int bgNormalColor  = 0xFFFFFFFF;
    private int bgPressedColor = 0xFFE0E0E0;
    private boolean isPressed  = false;

    public KeyButton(Context context) {
        super(context);
        init();
    }
    public KeyButton(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }
    public KeyButton(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init();
    }

    private void init() {
        letterPaint.setTextAlign(Paint.Align.CENTER);
        letterPaint.setFakeBoldText(true);
        letterPaint.setColor(Color.parseColor("#1A1A1A"));

        symbolPaint.setTextAlign(Paint.Align.RIGHT);
        symbolPaint.setColor(Color.parseColor("#888888"));

        setClickable(true);
        setLongClickable(true);
    }

    public void setLetter(String letter) {
        this.letter = letter != null ? letter : "";
        invalidate();
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol != null ? symbol : "";
        invalidate();
    }

    public String getLetter() { return letter; }
    public String getSymbol() { return symbol; }

    public void setColors(int normalColor, int pressedColor, int textColor) {
        this.bgNormalColor  = normalColor;
        this.bgPressedColor = pressedColor;
        letterPaint.setColor(textColor);
        invalidate();
    }

    @Override
    public void setPressed(boolean pressed) {
        super.setPressed(pressed);
        isPressed = pressed;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int w = getWidth();
        int h = getHeight();
        float margin = 3f;
        float radius  = 8f;

        // Фон
        bgPaint.setColor(isPressed ? bgPressedColor : bgNormalColor);
        bgRect.set(margin, margin, w - margin, h - margin);
        canvas.drawRoundRect(bgRect, radius, radius, bgPaint);

        // Буква — по центру, ~55% высоты кнопки
        float letterSize = h * 0.45f;
        letterPaint.setTextSize(letterSize);
        float letterY = h * 0.5f - (letterPaint.descent() + letterPaint.ascent()) / 2f;
        canvas.drawText(letter, w / 2f, letterY, letterPaint);

        // Символ — правый верхний угол, ~18% высоты
        if (!symbol.isEmpty()) {
            float symSize = h * 0.18f;
            symbolPaint.setTextSize(symSize);
            float symX = w - margin - 6f;
            float symY = margin + symSize + 2f;
            canvas.drawText(symbol, symX, symY, symbolPaint);
        }
    }
}

package com.numkey.ime;

import android.content.SharedPreferences;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.inputmethodservice.InputMethodService;
import android.os.Build;
import android.os.Handler;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.PopupMenu;
import android.widget.Toast;

public class NumKeyIMEService extends InputMethodService implements View.OnClickListener {

    public static final String PREFS_NAME             = "numkey_prefs";
    public static final String KEY_ROW_HEIGHT         = "row_height_dp";
    public static final int    DEFAULT_ROW_HEIGHT      = 64;
    public static final String KEY_ALPHA_ROW_HEIGHT    = "alpha_row_height_dp";
    public static final int    DEFAULT_ALPHA_ROW_HEIGHT = 60;
    private static final String KEY_LAST_MODE         = "last_mode";
    private static final String KEY_PINNED            = "keyboard_pinned";
    private static final String WMS_TEXT              = "10.1.0.145";

    private static final int MODE_NUM   = 0;
    private static final int MODE_ALPHA = 1;
    private static final int MODE_SYM   = 2;
    private static final int MODE_SYM2  = 3;

    private static final int SHIFT_OFF  = 0;
    private static final int SHIFT_ONE  = 1;
    private static final int SHIFT_CAPS = 2;

    private static final int LANG_EN = 0;
    private static final int LANG_RU = 1;
    private static final int LANG_UK = 2;

    private int currentMode = MODE_NUM;
    private int shiftState  = SHIFT_OFF;
    private int currentLang = LANG_EN;
    private boolean isPinned = false;

    private static final String[] EN_KEYS = {
        "q","w","e","r","t","y","u","i","o","p",
        "a","s","d","f","g","h","j","k","l",
        "z","x","c","v","b","n","m",
        "","","","",""
    };
    private static final String[] RU_KEYS = {
        "\u0439","\u0446","\u0443","\u043a","\u0435","\u043d","\u0433","\u0448","\u0449","\u0437",
        "\u0444","\u044b","\u0432","\u0430","\u043f","\u0440","\u043e","\u043b","\u0434",
        "\u044f","\u0447","\u0441","\u043c","\u0438","\u0442","\u044c",
        "\u0445","\u0436","\u044d","\u0431","\u044e"
    };
    private static final String[] UK_KEYS = {
        "\u0439","\u0446","\u0443","\u043a","\u0435","\u043d","\u0433","\u0448","\u0449","\u0437",
        "\u0444","\u0456","\u0432","\u0430","\u043f","\u0440","\u043e","\u043b","\u0434",
        "\u044f","\u0447","\u0441","\u043c","\u0438","\u0442","\u044c",
        "\u0445","\u0436","\u0454","\u0431","\u044e","\u0457"
    };

    private static final String[][] LAYOUTS     = { EN_KEYS, RU_KEYS, UK_KEYS };
    private static final String[]   LANG_LABELS = {
        "QWERTY",
        "\u0420\u0443\u0441\u0441\u043a\u0438\u0439",
        "\u0423\u043a\u0440\u0430\u0457\u043d\u0441\u044c\u043a\u0430"
    };

    private static final String[] KEY_SYMBOLS = {
        "%","\\","|","=","[","]","<",">","{","}",
        "@","#","$","-","&","-","+","(",")",
        "*","\"","'",":",";","!","?"
    };

    private static final String[] DOT_POPUP_SYMBOLS = {
        "&", "%", "+", "\"", "-", ":", "'", "@",
        ";", "/", "(", ")", "#", "!", ",", "?"
    };

    private static final int[] LETTER_IDS = {
        R.id.a_k0,R.id.a_k1,R.id.a_k2,R.id.a_k3,R.id.a_k4,
        R.id.a_k5,R.id.a_k6,R.id.a_k7,R.id.a_k8,R.id.a_k9,
        R.id.a_k10,R.id.a_k11,R.id.a_k12,R.id.a_k13,R.id.a_k14,
        R.id.a_k15,R.id.a_k16,R.id.a_k17,R.id.a_k18,
        R.id.a_k19,R.id.a_k20,R.id.a_k21,R.id.a_k22,
        R.id.a_k23,R.id.a_k24,R.id.a_k25
    };
    private static final int[] EXTRA_IDS = {
        R.id.a_k9b,R.id.a_k9c,R.id.a_k18b,R.id.a_k18c,R.id.a_k25b,R.id.a_k25c
    };
    private static final int[] EXTRA_LAYOUT_IDX = { 26,31,27,28,29,30 };

    private static final int[] ALPHA_NUM_IDS = {
        R.id.a_n1,R.id.a_n2,R.id.a_n3,R.id.a_n4,R.id.a_n5,
        R.id.a_n6,R.id.a_n7,R.id.a_n8,R.id.a_n9,R.id.a_n0
    };
    private static final int[] SYM_NUM_IDS = {
        R.id.s_n1,R.id.s_n2,R.id.s_n3,R.id.s_n4,R.id.s_n5,
        R.id.s_n6,R.id.s_n7,R.id.s_n8,R.id.s_n9,R.id.s_n0
    };
    private static final int[] SYM_IDS = {
        R.id.s_k0,R.id.s_k1,R.id.s_k2,R.id.s_k3,R.id.s_k4,
        R.id.s_k5,R.id.s_k6,R.id.s_k7,R.id.s_k8,R.id.s_k9,
        R.id.s_k10,R.id.s_k11,R.id.s_k12,R.id.s_k13,R.id.s_k14,
        R.id.s_k15,R.id.s_k16
    };
    private static final String[] SYM_VALS = {
        "@","#","$","_","&","-","+","(",")","/",
        "*","\"","'",":",";","!","?"
    };
    private static final int[] SYM2_IDS = {
        R.id.s2_k0,R.id.s2_k1,R.id.s2_k2,R.id.s2_k3,R.id.s2_k4,
        R.id.s2_k5,R.id.s2_k6,R.id.s2_k7,R.id.s2_k8,R.id.s2_k9,
        R.id.s2_k10,R.id.s2_k11,R.id.s2_k12,R.id.s2_k13,R.id.s2_k14,
        R.id.s2_k15,R.id.s2_k16,R.id.s2_k17,R.id.s2_k18,R.id.s2_k19,
        R.id.s2_k20,R.id.s2_k21,R.id.s2_k22,R.id.s2_k23,R.id.s2_k24,
        R.id.s2_k25,R.id.s2_k26
    };
    private static final String[] SYM2_VALS = {
        "~","`","|","\u2022","\u221a","\u03c0","\u00f7","\u00d7","\u00a7","\u25b3",
        "\u00a3","\u00a2","\u20ac","\u00a5","^","\u00b0","=","{","}","\\",
        "%","\u00a9","\u00ae","\u2122","\u2713","[","]"
    };

    private final Handler bsHandler = new Handler();
    private boolean bsHeld = false;
    private static final int BS_INITIAL = 400;
    private static final int BS_REPEAT  = 80;
    private final Runnable bsRunnable = new Runnable() {
        @Override public void run() {
            if (!bsHeld) return;
            InputConnection ic = getCurrentInputConnection();
            if (ic != null) ic.deleteSurroundingText(1, 0);
            bsHandler.postDelayed(this, BS_REPEAT);
        }
    };

    // ── Вибрация ──────────────────────────────────────────────────────────
    private void vibrate() {
        try {
            Vibrator vib = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (vib == null || !vib.hasVibrator()) return;
            // Работает на Android 7+ включая Newland MT90
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vib.vibrate(VibrationEffect.createOneShot(40, 80));
            } else {
                // Android 7 и ниже
                vib.vibrate(40);
            }
        } catch (Exception ignored) {}
    }

    // ── onCreateInputView ─────────────────────────────────────────────────
    @Override
    public View onCreateInputView() {
        isPinned = getPrefs().getBoolean(KEY_PINNED, false);
        currentMode = getPrefs().getInt(KEY_LAST_MODE, MODE_NUM);
        return buildView(currentMode);
    }

    @Override
    public boolean onEvaluateInputViewShown() {
        if (isPinned && currentMode == MODE_NUM) return true;
        return super.onEvaluateInputViewShown();
    }

    // ── onComputeInsets — клавиатура всегда выше навигации ────────────────
    @Override
    public void onComputeInsets(InputMethodService.Insets outInsets) {
        super.onComputeInsets(outInsets);
        outInsets.visibleTopInsets = outInsets.contentTopInsets;
        outInsets.touchableInsets  = InputMethodService.Insets.TOUCHABLE_INSETS_CONTENT;
    }

    /** Применяет padding снизу = высота системной навигации */
    private void applyNavPadding(View root) {
        if (root == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                int navH = insets.getStableInsetBottom();
                if (navH > 0) {
                    v.setPadding(v.getPaddingLeft(), v.getPaddingTop(),
                                 v.getPaddingRight(), navH);
                }
                return insets;
            });
            root.requestApplyInsets();
        }
    }

    private View buildView(int mode) {
        switch (mode) {
            case MODE_ALPHA: return buildAlphaView();
            case MODE_SYM:   return buildSymView();
            case MODE_SYM2:  return buildSym2View();
            default:         return buildNumView();
        }
    }

    private View buildNumView() {
        LayoutInflater inf = LayoutInflater.from(this);
        View v = inf.inflate(R.layout.keyboard, null);
        // Применяем высоту через post() — после того как view получит размеры
        final int rowH = getRowHeightPx();
        v.post(() -> applyGridRowHeight(v, rowH));

        int[] numDigitIds = {
            R.id.btn_0,R.id.btn_1,R.id.btn_2,R.id.btn_3,R.id.btn_4,
            R.id.btn_5,R.id.btn_6,R.id.btn_7,R.id.btn_8,R.id.btn_9
        };
        for (int id : numDigitIds) {
            Button b = v.findViewById(id);
            if (b != null) b.setOnClickListener(this);
        }

        v.findViewById(R.id.btn_dot).setOnClickListener(this);
        v.findViewById(R.id.btn_dot).setOnLongClickListener(a -> {
            switchMode(MODE_ALPHA); return true;
        });

        setupBackspaceHold(v.findViewById(R.id.btn_backspace));
        v.findViewById(R.id.btn_backspace).setOnClickListener(this);

        Button wms = v.findViewById(R.id.btn_wms);
        wms.setOnClickListener(this);
        wms.setOnLongClickListener(a -> { togglePin(v); return true; });
        wms.setText(isPinned ? "wms \uD83D\uDCCC" : "wms");

        v.findViewById(R.id.btn_ok).setOnClickListener(this);
        v.findViewById(R.id.btn_ok).setOnLongClickListener(a -> { showImePicker(); return true; });

        applyTheme(v, getCurrentTheme());
        applyNavPadding(v);
        return v;
    }

    private View buildAlphaView() {
        LayoutInflater inf = LayoutInflater.from(this);
        View v = inf.inflate(R.layout.keyboard_alpha, null);
        applyAlphaRowHeight(v);

        for (int i = 0; i < LETTER_IDS.length; i++) {
            final int idx = i;
            Button b = v.findViewById(LETTER_IDS[i]);
            if (b == null) continue;
            b.setOnClickListener(this);
            if (idx < KEY_SYMBOLS.length) {
                b.setOnLongClickListener(a -> {
                    InputConnection ic = getCurrentInputConnection();
                    if (ic != null) ic.commitText(getSymbol(idx), 1);
                    return true;
                });
            }
        }
        for (int i = 0; i < EXTRA_IDS.length; i++) {
            Button b = v.findViewById(EXTRA_IDS[i]);
            if (b != null) b.setOnClickListener(this);
        }
        for (int id : ALPHA_NUM_IDS) {
            Button b = v.findViewById(id);
            if (b != null) b.setOnClickListener(this);
        }
        v.findViewById(R.id.a_shift).setOnClickListener(this);
        v.findViewById(R.id.a_dot2).setOnClickListener(this);
        final View dot2 = v.findViewById(R.id.a_dot2);
        dot2.setOnLongClickListener(a -> { showDotPopup(dot2); return true; });
        v.findViewById(R.id.a_comma2).setOnClickListener(this);
        v.findViewById(R.id.a_ok).setOnClickListener(this);
        v.findViewById(R.id.a_ok).setOnLongClickListener(a -> { showImePicker(); return true; });
        v.findViewById(R.id.a_to_sym).setOnClickListener(this);
        v.findViewById(R.id.a_to_num).setOnClickListener(this);
        Button langBtn = v.findViewById(R.id.a_lang);
        langBtn.setOnClickListener(this);
        langBtn.setOnLongClickListener(a -> { showImePicker(); return true; });
        Button spaceBtn = v.findViewById(R.id.a_space);
        spaceBtn.setOnClickListener(this);
        spaceBtn.setOnLongClickListener(a -> {
            currentLang = (currentLang + 1) % LAYOUTS.length;
            switchMode(MODE_ALPHA);
            return true;
        });
        setupBackspaceHold(v.findViewById(R.id.a_bs));
        applyAlphaLabels(v);
        applyNavPadding(v);
        return v;
    }

    private View buildSymView() {
        LayoutInflater inf = LayoutInflater.from(this);
        View v = inf.inflate(R.layout.keyboard_sym, null);
        for (int id : SYM_IDS) { Button b = v.findViewById(id); if (b != null) b.setOnClickListener(this); }
        for (int id : SYM_NUM_IDS) { Button b = v.findViewById(id); if (b != null) b.setOnClickListener(this); }
        v.findViewById(R.id.s_to_alpha).setOnClickListener(this);
        v.findViewById(R.id.s_to_sym2).setOnClickListener(this);
        v.findViewById(R.id.s_space).setOnClickListener(this);
        v.findViewById(R.id.s_comma).setOnClickListener(this);
        v.findViewById(R.id.s_dot).setOnClickListener(this);
        v.findViewById(R.id.s_ok).setOnClickListener(this);
        v.findViewById(R.id.s_ok).setOnLongClickListener(a -> { showImePicker(); return true; });
        setupBackspaceHold(v.findViewById(R.id.s_bs));
        applyNavPadding(v);
        return v;
    }

    private View buildSym2View() {
        LayoutInflater inf = LayoutInflater.from(this);
        View v = inf.inflate(R.layout.keyboard_sym2, null);
        for (int id : SYM2_IDS) { Button b = v.findViewById(id); if (b != null) b.setOnClickListener(this); }
        v.findViewById(R.id.s2_to_alpha).setOnClickListener(this);
        v.findViewById(R.id.s2_to_sym).setOnClickListener(this);
        v.findViewById(R.id.s2_space).setOnClickListener(this);
        v.findViewById(R.id.s2_lt).setOnClickListener(this);
        v.findViewById(R.id.s2_gt).setOnClickListener(this);
        v.findViewById(R.id.s2_ok).setOnClickListener(this);
        v.findViewById(R.id.s2_ok).setOnLongClickListener(a -> { showImePicker(); return true; });
        setupBackspaceHold(v.findViewById(R.id.s2_bs));
        applyNavPadding(v);
        return v;
    }

    private void switchMode(int mode) {
        currentMode = mode;
        getPrefs().edit().putInt(KEY_LAST_MODE, mode).apply();
        View newView = buildView(mode);
        setInputView(newView);
    }

    private void togglePin(View numView) {
        isPinned = !isPinned;
        getPrefs().edit().putBoolean(KEY_PINNED, isPinned).apply();
        String msg = isPinned
            ? "\u0417\u0430\u043a\u0440\u0435\u043f\u043b\u0435\u043d\u043e \uD83D\uDCCC"
            : "\u0420\u0430\u0437\u043a\u0440\u0435\u043f\u043b\u0435\u043d\u043e";
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
        Button wms = numView.findViewById(R.id.btn_wms);
        if (wms != null) wms.setText(isPinned ? "wms \uD83D\uDCCC" : "wms");
    }

    // ── Метки букв ────────────────────────────────────────────────────────
    private void applyAlphaLabels(View root) {
        if (root == null) return;
        String[] keys = LAYOUTS[currentLang];
        boolean upper = (shiftState != SHIFT_OFF);
        boolean isLatin = (currentLang == LANG_EN);

        for (int i = 0; i < LETTER_IDS.length && i < 26; i++) {
            Button b = root.findViewById(LETTER_IDS[i]);
            if (b == null) continue;
            String letter = i < keys.length ? keys[i] : "";
            String sym    = getSymbol(i);
            String disp   = (upper && !letter.isEmpty()) ? letter.toUpperCase() : letter;
            b.setText(makeLabel(disp, sym));
        }
        for (int i = 0; i < EXTRA_IDS.length; i++) {
            Button b = root.findViewById(EXTRA_IDS[i]);
            if (b == null) continue;
            int idx = EXTRA_LAYOUT_IDX[i];
            String letter = idx < keys.length ? keys[idx] : "";
            if (isLatin || letter.isEmpty()) {
                b.setVisibility(View.GONE);
            } else {
                b.setVisibility(View.VISIBLE);
                b.setText(upper ? letter.toUpperCase() : letter);
            }
        }
        Button spaceBtn = root.findViewById(R.id.a_space);
        if (spaceBtn != null) spaceBtn.setText(LANG_LABELS[currentLang]);
    }

    private SpannableString makeLabel(String letter, String sym) {
        if (sym.isEmpty()) return new SpannableString(letter);
        String full = letter + "\n" + sym;
        SpannableString ss = new SpannableString(full);
        int s = letter.length() + 1;
        ss.setSpan(new RelativeSizeSpan(0.38f),       s, full.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        ss.setSpan(new ForegroundColorSpan(0xFF888888), s, full.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        return ss;
    }

    private String getSymbol(int idx) {
        if (idx == 12 && currentLang == LANG_UK) return "\u20b4";
        return idx < KEY_SYMBOLS.length ? KEY_SYMBOLS[idx] : "";
    }

    // ── Высота ────────────────────────────────────────────────────────────
    private int getRowHeightPx() {
        int dp = getPrefs().getInt(KEY_ROW_HEIGHT, DEFAULT_ROW_HEIGHT);
        return (int) TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, dp, getResources().getDisplayMetrics());
    }

    private void applyGridRowHeight(View root, int rowH) {
        GridLayout grid = root.findViewById(R.id.grid_num);
        if (grid == null) return;
        int gap = (int) TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, 6, getResources().getDisplayMetrics());
        for (int i = 0; i < grid.getChildCount(); i++) {
            View child = grid.getChildAt(i);
            GridLayout.LayoutParams lp = (GridLayout.LayoutParams) child.getLayoutParams();
            int rowSpan = 1;
            Object tag = child.getTag();
            if (tag != null) {
                try { rowSpan = Integer.parseInt(tag.toString()); } catch (Exception ignored) {}
            }
            lp.height = rowH * rowSpan + (rowSpan > 1 ? gap : 0);
            child.setLayoutParams(lp);
        }
        grid.requestLayout();
    }

    private void applyAlphaRowHeight(View root) {
        int dp = getPrefs().getInt(KEY_ALPHA_ROW_HEIGHT, DEFAULT_ALPHA_ROW_HEIGHT);
        int px = (int) TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, dp, getResources().getDisplayMetrics());
        if (!(root instanceof android.view.ViewGroup)) return;
        android.view.ViewGroup vg = (android.view.ViewGroup) root;
        for (int i = 0; i < vg.getChildCount(); i++) {
            View child = vg.getChildAt(i);
            if (child instanceof android.widget.LinearLayout) {
                android.widget.LinearLayout row = (android.widget.LinearLayout) child;
                if (row.getOrientation() == android.widget.LinearLayout.HORIZONTAL) {
                    android.view.ViewGroup.LayoutParams lp = row.getLayoutParams();
                    if (lp != null && lp.height > 0) { lp.height = px; row.setLayoutParams(lp); }
                }
            }
        }
    }

    // ── Тема ──────────────────────────────────────────────────────────────
    private Theme getCurrentTheme() {
        return Theme.findById(getPrefs().getString("theme_id", "blue"));
    }

    private android.graphics.drawable.Drawable makeDrawable(int normal, int pressed) {
        GradientDrawable n = new GradientDrawable(); n.setColor(normal);  n.setCornerRadius(12f);
        GradientDrawable p = new GradientDrawable(); p.setColor(pressed); p.setCornerRadius(12f);
        StateListDrawable sl = new StateListDrawable();
        sl.addState(new int[]{android.R.attr.state_pressed}, p);
        sl.addState(new int[]{}, n);
        return sl;
    }

    private void applyTheme(View root, Theme t) {
        if (root == null || t == null) return;
        root.setBackgroundColor(t.background);
        applyThemeGroup((android.view.ViewGroup) root, t);
    }

    private void applyThemeGroup(android.view.ViewGroup vg, Theme t) {
        for (int i = 0; i < vg.getChildCount(); i++) {
            View child = vg.getChildAt(i);
            if (child instanceof android.view.ViewGroup) {
                child.setBackgroundColor(t.background);
                applyThemeGroup((android.view.ViewGroup) child, t);
            } else if (child instanceof Button) {
                Button btn = (Button) child;
                int id = btn.getId();
                if (id == R.id.btn_wms) continue;
                if (id == R.id.btn_ok) {
                    btn.setBackground(makeDrawable(t.btnOkNormal, t.btnOkPressed));
                } else if (id == R.id.btn_backspace || id == R.id.btn_dot) {
                    btn.setBackground(makeDrawable(t.btnDarkNormal, t.btnDarkPressed));
                } else {
                    btn.setTextColor(t.textColor);
                    btn.setBackground(makeDrawable(t.btnMainNormal, t.btnMainPressed));
                }
            }
        }
    }

    // ── Backspace hold ────────────────────────────────────────────────────
    private void setupBackspaceHold(View btn) {
        if (btn == null) return;
        btn.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    bsHeld = true;
                    InputConnection ic = getCurrentInputConnection();
                    if (ic != null) ic.deleteSurroundingText(1, 0);
                    bsHandler.postDelayed(bsRunnable, BS_INITIAL);
                    v.setPressed(true);
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    bsHeld = false;
                    bsHandler.removeCallbacks(bsRunnable);
                    v.setPressed(false);
                    return true;
            }
            return false;
        });
    }

    private void showDotPopup(View anchor) {
        PopupMenu popup = new PopupMenu(this, anchor);
        for (int i = 0; i < DOT_POPUP_SYMBOLS.length; i++)
            popup.getMenu().add(0, i, i, DOT_POPUP_SYMBOLS[i]);
        popup.setOnMenuItemClickListener(item -> {
            InputConnection ic = getCurrentInputConnection();
            if (ic != null) ic.commitText(DOT_POPUP_SYMBOLS[item.getItemId()], 1);
            return true;
        });
        popup.show();
    }

    private void showImePicker() {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.showInputMethodPicker();
    }

    private SharedPreferences getPrefs() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
    }

    // ── Enter — всегда KEYCODE_ENTER ──────────────────────────────────────
    private void doEnter() {
        sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER);
    }

    @Override
    public void onStartInput(EditorInfo attribute, boolean restarting) {
        super.onStartInput(attribute, restarting);
        shiftState = SHIFT_OFF;
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();

        // WMS
        if (id == R.id.btn_wms) {
            vibrate();
            InputConnection ic = getCurrentInputConnection();
            if (ic != null) ic.commitText(WMS_TEXT, 1);
            doEnter();
            return;
        }

        // Переключение режимов
        if (id == R.id.a_to_num)    { switchMode(MODE_NUM);   return; }
        if (id == R.id.a_to_sym)    { switchMode(MODE_SYM);   return; }
        if (id == R.id.s_to_alpha || id == R.id.s2_to_alpha) { switchMode(MODE_ALPHA); return; }
        if (id == R.id.s_to_sym2)   { switchMode(MODE_SYM2);  return; }
        if (id == R.id.s2_to_sym)   { switchMode(MODE_SYM);   return; }
        if (id == R.id.s_space)     { switchMode(MODE_SYM);   return; }

        // Смена языка
        if (id == R.id.a_lang) {
            currentLang = (currentLang + 1) % LAYOUTS.length;
            switchMode(MODE_ALPHA);
            return;
        }

        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;

        // Shift
        if (id == R.id.a_shift) {
            if      (shiftState == SHIFT_OFF) shiftState = SHIFT_ONE;
            else if (shiftState == SHIFT_ONE) shiftState = SHIFT_CAPS;
            else                              shiftState = SHIFT_OFF;
            switchMode(MODE_ALPHA);
            return;
        }

        // Enter — с вибрацией на числовой
        if (id == R.id.btn_ok) { vibrate(); doEnter(); return; }
        if (id == R.id.a_ok || id == R.id.s_ok || id == R.id.s2_ok) { doEnter(); return; }

        // Backspace одиночный
        if (id == R.id.btn_backspace) { ic.deleteSurroundingText(1, 0); return; }

        // Точка / запятая / пробел
        if (id == R.id.btn_dot || id == R.id.a_dot2 || id == R.id.s_dot) { ic.commitText(".", 1); return; }
        if (id == R.id.a_comma2 || id == R.id.s_comma) { ic.commitText(",", 1); return; }
        if (id == R.id.a_space || id == R.id.s2_space) { ic.commitText(" ", 1); return; }
        if (id == R.id.s2_lt) { ic.commitText("<", 1); return; }
        if (id == R.id.s2_gt) { ic.commitText(">", 1); return; }

        // Цифры числовой — с вибрацией
        int[] numIds = { R.id.btn_0,R.id.btn_1,R.id.btn_2,R.id.btn_3,R.id.btn_4,
                         R.id.btn_5,R.id.btn_6,R.id.btn_7,R.id.btn_8,R.id.btn_9 };
        for (int nid : numIds) {
            if (id == nid) {
                vibrate();
                ic.commitText(((Button)v).getText().toString(), 1);
                return;
            }
        }

        // Цифры верхних рядов
        for (int nid : ALPHA_NUM_IDS) { if (id == nid) { ic.commitText(((Button)v).getText().toString(), 1); return; } }
        for (int nid : SYM_NUM_IDS)   { if (id == nid) { ic.commitText(((Button)v).getText().toString(), 1); return; } }

        // Символы
        for (int i = 0; i < SYM_IDS.length;  i++) { if (id == SYM_IDS[i])  { ic.commitText(SYM_VALS[i],  1); return; } }
        for (int i = 0; i < SYM2_IDS.length; i++) { if (id == SYM2_IDS[i]) { ic.commitText(SYM2_VALS[i], 1); return; } }

        // Доп. буквы RU/UK
        for (int i = 0; i < EXTRA_IDS.length; i++) {
            if (id == EXTRA_IDS[i]) {
                String[] keys = LAYOUTS[currentLang];
                int idx = EXTRA_LAYOUT_IDX[i];
                String letter = idx < keys.length ? keys[idx] : "";
                if (!letter.isEmpty()) {
                    boolean upper = (shiftState != SHIFT_OFF);
                    ic.commitText(upper ? letter.toUpperCase() : letter, 1);
                    if (shiftState == SHIFT_ONE) { shiftState = SHIFT_OFF; switchMode(MODE_ALPHA); }
                }
                return;
            }
        }

        // Буквы
        for (int i = 0; i < LETTER_IDS.length; i++) {
            if (id == LETTER_IDS[i]) {
                String[] keys = LAYOUTS[currentLang];
                boolean upper = (shiftState != SHIFT_OFF);
                String letter = i < keys.length ? keys[i] : "";
                ic.commitText(upper ? letter.toUpperCase() : letter, 1);
                if (shiftState == SHIFT_ONE) { shiftState = SHIFT_OFF; switchMode(MODE_ALPHA); }
                return;
            }
        }
    }

    @Override
    public void onFinishInput() {
        super.onFinishInput();
        bsHeld = false;
        bsHandler.removeCallbacks(bsRunnable);
    }
}
